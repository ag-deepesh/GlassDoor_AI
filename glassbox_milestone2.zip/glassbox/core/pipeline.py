"""
The orchestrator. Two ways to run it:

  - Step-by-step: call run_<stage>() one at a time yourself, inspecting the
    StageReport (output + eval + recommendation) before calling the next.
    The UI's "Require acknowledgment before advancing" setting is enforced
    at THIS level: run_all(interactive=True) will not call the next stage
    until on_stage_reviewed() returns True for the current one.
  - Run all: run_all(interactive=False) executes every stage back-to-back
    and returns all reports at the end.

Either way, every stage returns the exact same StageReport shape.
"""
from __future__ import annotations
import time
from pathlib import Path
from typing import Callable

from core.schemas import StageReport, TraceEvent
from core.pipeline_config import PipelineConfig
from core.registry import get
from core.parsing.assorted import EXT_TO_METHOD
from core.chunking.base import ChunkConfig
from core.vectorstore.chroma_store import ChromaStore
from core.retrieval.base import RetrievedItem
from core.retrieval.multimodal import query_images, merge_results
from core.evaluation import heuristics

# Import every registrable module for its registration side-effect -- this
# is the one place that needs to know all of them exist; everything else
# just calls registry.get(stage, method).
from core.parsing import assorted as _assorted  # noqa: F401 (pdf/docx/pptx/md/txt/assorted)
from core.chunking import fixed as _f, recursive as _r, sentence as _s, markdown_structure as _m, semantic as _sem  # noqa: F401,E501
from core.embedding import text_local as _tl, text_gemini as _tg, text_openai as _to  # noqa: F401
from core.reranking import reranking as _rr  # noqa: F401
from core.generation import generation as _gen  # noqa: F401
from core.retrieval import semantic as _rs, keyword as _rk, hybrid_rrf as _rh  # noqa: F401


class Pipeline:
    def __init__(self, config: PipelineConfig, workdir: Path):
        self.config = config
        self.workdir = Path(workdir)
        self.store = ChromaStore(self.workdir / "chroma")

        # Filled in progressively as stages run.
        self.docs = []
        self.chunks = []
        self.text_embedder = None
        self.retrieved: list[RetrievedItem] = []
        self.reranked: list[RetrievedItem] = []
        self.answer = None

    # -- helpers -------------------------------------------------------
    def _report(self, stage: str, method: str, t0: float, input_summary: str, output_summary: str,
                tokens: int = 0, cost: float = 0.0, ref_free: dict | None = None,
                ref_based: dict | None = None) -> StageReport:
        trace = TraceEvent(stage=stage, method=method, input_summary=input_summary,
                            output_summary=output_summary, latency_ms=round((time.time() - t0) * 1000, 1),
                            tokens=tokens, cost_usd=cost)
        return StageReport(stage=stage, method=method, output_preview=output_summary, trace=trace,
                            eval_reference_free=ref_free, eval_with_reference=ref_based)

    # -- stages ----------------------------------------------------------
    def run_parsing(self, input_dir: Path) -> StageReport:
        t0 = time.time()
        cfg = self.config
        paths = [p for p in Path(input_dir).iterdir() if p.suffix.lower() in EXT_TO_METHOD]
        parser_cls = get("parsing", cfg.parsing_method if cfg.parsing_method != "assorted" else "assorted")
        parser = parser_cls(extract_images=cfg.extract_images, ocr=cfg.ocr, assets_dir=self.workdir / "assets")
        self.docs = [parser.parse(p, doc_id=p.stem) for p in paths]

        report = heuristics.parsing_report(self.docs)
        total_words = sum(len(d.full_text.split()) for d in self.docs)
        return self._report("parsing", cfg.parsing_method, t0, f"{len(paths)} files",
                             f"{len(self.docs)} docs, {total_words} words", ref_free=report)

    def run_chunking(self) -> StageReport:
        t0 = time.time()
        cfg = self.config
        chunker_cls = get("chunking", cfg.chunking_method)
        chunker = chunker_cls(ChunkConfig(chunk_size=cfg.chunk_size, overlap=cfg.chunk_overlap))
        self.chunks = [c for doc in self.docs for c in chunker.chunk(doc)]

        report = heuristics.chunking_report(self.chunks, cfg.chunk_size)
        return self._report("chunking", cfg.chunking_method, t0, f"{len(self.docs)} docs",
                             f"{len(self.chunks)} chunks", ref_free=report)

    def run_embedding(self) -> StageReport:
        t0 = time.time()
        cfg = self.config
        embedder_cls = get("embedding", cfg.embedding_method)
        needs_key = cfg.embedding_method.startswith(("gemini", "openai"))
        provider = "gemini" if cfg.embedding_method.startswith("gemini") else "openai"
        self.text_embedder = embedder_cls(cfg.api_keys[provider]) if needs_key else embedder_cls()

        texts = [c.text for c in self.chunks]
        vectors = self.text_embedder.embed(texts) if texts else []
        self.store.add_chunks(self.chunks, vectors)

        n_images = sum(len(d.images) for d in self.docs)
        if n_images and cfg.image_embedding_method == "caption-text-embed":
            from core.embedding.image_caption import CaptionThenEmbed
            img_embedder = CaptionThenEmbed(self.text_embedder, cfg.caption_provider,
                                             cfg.api_keys[cfg.caption_provider])
            all_images = [img for d in self.docs for img in d.images]
            img_vectors = img_embedder.embed_images(all_images)
            self.store.add_images(all_images, img_vectors)

        report = heuristics.embedding_report(len(vectors), self.text_embedder.dim if vectors else 0, n_images)
        return self._report("embedding", cfg.embedding_method, t0, f"{len(texts)} chunks",
                             f"{len(vectors)} vectors", ref_free=report)

    def run_retrieval(self, query: str) -> StageReport:
        t0 = time.time()
        cfg = self.config
        from core.retrieval.semantic import SemanticRetriever
        from core.retrieval.keyword import KeywordRetriever
        from core.retrieval.hybrid_rrf import HybridRRFRetriever

        if cfg.retrieval_method == "semantic":
            retriever = SemanticRetriever(self.store, self.text_embedder, top_k=cfg.top_k)
        elif cfg.retrieval_method == "keyword":
            retriever = KeywordRetriever(self.store, top_k=cfg.top_k)
        elif cfg.retrieval_method == "hybrid-rrf":
            retriever = HybridRRFRetriever(SemanticRetriever(self.store, self.text_embedder, top_k=cfg.top_k),
                                            KeywordRetriever(self.store, top_k=cfg.top_k), top_k=cfg.top_k)
        else:
            raise ValueError(f"Unknown retrieval method '{cfg.retrieval_method}'")

        text_items = retriever.retrieve(query)
        image_items = []
        if cfg.result_mode != "text-only":
            q_emb = self.text_embedder.embed([query])[0]
            image_items = query_images(self.store, q_emb, top_k=4)
        self.retrieved = merge_results(text_items, image_items, mode=cfg.result_mode)

        report = heuristics.retrieval_report(self.retrieved)
        return self._report("retrieval", cfg.retrieval_method, t0, f"query: {query[:60]}",
                             f"{len(self.retrieved)} items ({len(image_items)} images)", ref_free=report)

    def run_reranking(self, query: str) -> StageReport:
        t0 = time.time()
        cfg = self.config
        reranker_cls = get("reranking", cfg.reranking_method)
        reranker = reranker_cls()
        self.reranked = reranker.rerank(query, self.retrieved, keep_top=cfg.rerank_keep_top)

        report = heuristics.retrieval_report(self.reranked)  # same shape of report, post-rerank
        return self._report("reranking", cfg.reranking_method, t0, f"{len(self.retrieved)} candidates",
                             f"{len(self.reranked)} kept", ref_free=report)

    def run_generation(self, query: str, reference: str | None = None) -> StageReport:
        t0 = time.time()
        cfg = self.config
        gen_cls = get("generation", cfg.generation_method)
        provider = gen_cls._provider
        generator = gen_cls(cfg.api_keys[provider])
        resp = generator.generate(cfg.system_prompt, query, self.reranked)
        self.answer = resp.text

        ref_free, ref_based = None, None
        try:
            from core.evaluation.ragas_eval import get_judge, reference_free_report, reference_based_report
            judge = get_judge(cfg.judge_provider, cfg.api_keys[cfg.judge_provider])
            contexts = [i.text for i in self.reranked]
            ref_free = reference_free_report(query, contexts, self.answer, judge).as_dict()
            if reference:
                ref_based = reference_based_report(query, contexts, self.answer, reference, judge).as_dict()
        except Exception as e:  # RAGAS/judge is best-effort -- generation output still stands without it
            ref_free = {"scores": {}, "recommendation": f"RAGAS scoring unavailable this run: {e}"}

        return self._report("generation", cfg.generation_method, t0, f"query: {query[:60]}",
                             self.answer[:200], tokens=resp.input_tokens + resp.output_tokens,
                             cost=resp.cost_usd, ref_free=ref_free, ref_based=ref_based)

    # -- orchestration ----------------------------------------------------
    def run_all(self, input_dir: Path, query: str, reference: str | None = None,
                interactive: bool = False,
                on_stage_reviewed: Callable[[StageReport], bool] | None = None) -> list[StageReport]:
        """interactive=True + on_stage_reviewed set: stop after each stage
        until the callback returns True (the 'click-through acknowledgment'
        requirement). interactive=False: run every stage back-to-back."""
        stage_fns = [
            lambda: self.run_parsing(input_dir),
            lambda: self.run_chunking(),
            lambda: self.run_embedding(),
            lambda: self.run_retrieval(query),
            lambda: self.run_reranking(query),
            lambda: self.run_generation(query, reference),
        ]
        reports = []
        for fn in stage_fns:
            report = fn()
            reports.append(report)
            if interactive and on_stage_reviewed is not None:
                report.acknowledged = on_stage_reviewed(report)
                if not report.acknowledged:
                    break
        return reports
