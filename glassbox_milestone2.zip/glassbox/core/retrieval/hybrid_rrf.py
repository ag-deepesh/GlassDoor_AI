from __future__ import annotations
from core.registry import register
from core.retrieval.base import BaseRetriever, RetrievedItem
from core.retrieval.semantic import SemanticRetriever
from core.retrieval.keyword import KeywordRetriever


@register("retrieval", "hybrid-rrf")
class HybridRRFRetriever(BaseRetriever):
    """Combines Semantic and Keyword rankings via Reciprocal Rank Fusion:
        RRF(d) = sum over each method's ranking of  1 / (k + rank_i(d))
    with the standard constant k=60. RRF only needs each method's RANK
    order, not its raw score -- which sidesteps the problem that cosine
    similarity and BM25 scores live on totally different scales and can't
    be averaged directly. Usually the best default: real queries mix exact
    terms and paraphrased concepts."""

    RRF_K = 60

    def __init__(self, semantic: SemanticRetriever, keyword: KeywordRetriever, top_k: int = 10):
        super().__init__(top_k)
        self._semantic = semantic
        self._keyword = keyword

    def retrieve(self, query: str) -> list[RetrievedItem]:
        # Over-fetch from each side so fusion has enough candidates to re-rank from.
        fetch_k = max(self.top_k * 2, 20)
        self._semantic.top_k = fetch_k
        self._keyword.top_k = fetch_k
        sem_results = self._semantic.retrieve(query)
        kw_results = self._keyword.retrieve(query)

        fused: dict[str, float] = {}
        by_id: dict[str, RetrievedItem] = {}
        for ranking in (sem_results, kw_results):
            for rank, item in enumerate(ranking):
                fused[item.id] = fused.get(item.id, 0.0) + 1.0 / (self.RRF_K + rank + 1)
                by_id[item.id] = item

        top_ids = sorted(fused, key=lambda id_: -fused[id_])[:self.top_k]
        return [RetrievedItem(id=id_, text=by_id[id_].text, score=fused[id_], kind="text", meta=by_id[id_].meta)
                for id_ in top_ids]
